<?php

die('Restricted access');