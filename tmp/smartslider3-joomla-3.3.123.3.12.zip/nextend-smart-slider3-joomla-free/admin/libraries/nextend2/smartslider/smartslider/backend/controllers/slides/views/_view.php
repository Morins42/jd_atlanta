<?php

class N2SmartsliderBackendSlidesView extends N2ViewBase
{

} 