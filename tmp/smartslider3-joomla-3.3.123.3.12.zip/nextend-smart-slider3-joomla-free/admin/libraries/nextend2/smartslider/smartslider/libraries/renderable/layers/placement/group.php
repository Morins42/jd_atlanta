<?php

class  N2SSSlidePlacementGroup extends N2SSSlidePlacement {

    public function attributes(&$attributes) {

        $attributes['data-pm'] = 'group';
    }
}