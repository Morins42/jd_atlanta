<?php
N2Loader::import('libraries.form.elements.text');

class N2ElementPassword extends N2ElementText {

    public $fieldType = 'password';
}